<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/317b7b0c-a263-4a1e-8a21-a7a25d81262a

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## مدير الملفات عبر Telegram

- أرسل الأمر `/files` إلى البوت المرتبط بالتطبيق لفتح مدير ملفات الهاتف.
- اضغط اسم المجلد للدخول إليه، واستخدم زر الرجوع أو أزرار الصفحات للتنقل.
- اضغط `📤` بجانب الملف لإرساله إلى المحادثة. تُرسل الصور الصغيرة كصور، والفيديو كفيديو، والملفات الأخرى كمستندات.
- اضغط `📦 ZIP` بجانب المجلد لضغط محتوياته وإرسالها كملف ZIP.
- يقتصر التحكم على المحادثة الخاصة ومعرّف المستخدم المحدد في إعدادات Telegram.
- يلزم منح التطبيق صلاحية **إدارة جميع الملفات** من إعدادات Android. مجلدا `Android/data` و`Android/obb` مستثنيان من التصفح.
- الحد الأقصى للإرسال الواحد 49 ميجابايت؛ المجلدات الأكبر تحتاج إلى اختيار مجلدات أصغر.
- نتائج التنزيل والرفع تظهر في محادثة Telegram، ولا تُنشأ إشعارات محلية لعمليات التنزيل.
