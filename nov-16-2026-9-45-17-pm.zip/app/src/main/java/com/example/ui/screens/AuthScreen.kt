package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.MutableContextWrapper
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.example.ui.theme.DangerRed
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.OAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private const val AUTH_TAG = "AuthScreen"

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

suspend fun attemptSilentGoogleSignIn(
    context: Context,
    credentialManager: CredentialManager
): Boolean {
    if (Firebase.auth.currentUser != null) return true
    val fbConfig = com.example.util.FirebaseDiagnosticsHelper.inspectFirebaseConfig(context)
    if (fbConfig.isDummyFallback || !fbConfig.isConfigComplete) return false
    val webClientId = fbConfig.webClientId
    if (webClientId.isBlank()) return false
    val activity = context.findActivity()
    val uiContext: Context = if (activity != null) MutableContextWrapper(activity) else context
    return try {
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(true)
            .setServerClientId(webClientId)
            .setAutoSelectEnabled(true)
            .build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()
        val result = credentialManager.getCredential(uiContext, request)
        val cred = result.credential
        if (cred is CustomCredential &&
            cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            val googleToken = GoogleIdTokenCredential.createFrom(cred.data)
            val firebaseCred = GoogleAuthProvider.getCredential(googleToken.idToken, null)
            Firebase.auth.signInWithCredential(firebaseCred).await()
            true
        } else {
            false
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: GetCredentialException) {
        Log.d(AUTH_TAG, "Silent Google sign-in skipped (${e.type}): ${e.message}")
        false
    } catch (e: Exception) {
        Log.d(AUTH_TAG, "Silent Google sign-in error: ${e.message}")
        false
    }
}

suspend fun performBrowserGoogleOAuthSignIn(context: Context): GoogleSignInOutcome {
    val fbConfig = com.example.util.FirebaseDiagnosticsHelper.inspectFirebaseConfig(context)
    if (fbConfig.isDummyFallback || !fbConfig.isConfigComplete) {
        return GoogleSignInOutcome.Error(
            com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                rawMessage = "API key not valid",
                context = context
            )
        )
    }
    val activity = context.findActivity()
        ?: return GoogleSignInOutcome.Error("تعذر فتح نافذة اختيار حساب Google خارج سياق الشاشة النشطة.")
    return try {
        val pending = Firebase.auth.pendingAuthResult?.await()
        if (pending?.user != null) {
            return GoogleSignInOutcome.Success
        }
        val provider = OAuthProvider.newBuilder("google.com")
            .addCustomParameter("prompt", "select_account")
            .build()
        val result = Firebase.auth.startActivityForSignInWithProvider(activity, provider).await()
        if (result.user != null) {
            GoogleSignInOutcome.Success
        } else {
            GoogleSignInOutcome.Error("لم تكتمل المصادقة بحساب Google. يرجى المحاولة مرة أخرى.")
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e(AUTH_TAG, "OAuthProvider Google sign-in failure", e)
        val msg = e.localizedMessage.orEmpty()
        if (msg.contains("canceled", ignoreCase = true) || msg.contains("cancelled", ignoreCase = true)) {
            GoogleSignInOutcome.Cancelled(
                com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                    rawMessage = msg,
                    context = context,
                    isCancellation = true
                )
            )
        } else {
            GoogleSignInOutcome.Error(
                com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                    rawMessage = msg,
                    context = context
                )
            )
        }
    }
}

suspend fun performGoogleSignIn(
    context: Context,
    credentialManager: CredentialManager
): GoogleSignInOutcome {
    val fbConfig = com.example.util.FirebaseDiagnosticsHelper.inspectFirebaseConfig(context)
    if (fbConfig.isDummyFallback || !fbConfig.isConfigComplete) {
        return GoogleSignInOutcome.Error(
            com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                rawMessage = "API key not valid",
                context = context
            )
        )
    }
    val webClientId = fbConfig.webClientId
    if (webClientId.isBlank()) {
        return GoogleSignInOutcome.Error("معرف عميل Web (default_web_client_id) غير مهيأ في إعدادات Firebase.")
    }

    val activity = context.findActivity()
    val uiContext: Context = if (activity != null) MutableContextWrapper(activity) else context

    suspend fun signInWithResponseCredential(credential: androidx.credentials.Credential): GoogleSignInOutcome {
        return if (credential is CustomCredential &&
            credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
            val firebaseCred = GoogleAuthProvider.getCredential(googleCred.idToken, null)
            Firebase.auth.signInWithCredential(firebaseCred).await()
            GoogleSignInOutcome.Success
        } else {
            GoogleSignInOutcome.Error("نوع بيانات الاعتماد المستلمة غير مدعوم لتسجيل الدخول.")
        }
    }

    suspend fun runGoogleIdOptionFallback(filterByAuthorized: Boolean): GoogleSignInOutcome {
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(filterByAuthorized)
            .setServerClientId(webClientId)
            .setAutoSelectEnabled(false)
            .build()
        val fallbackRequest = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()
        val response = credentialManager.getCredential(uiContext, fallbackRequest)
        return signInWithResponseCredential(response.credential)
    }

    // Request 1: Primary interactive GetSignInWithGoogleOption (1 option per request)
    val startTimeMs = System.currentTimeMillis()
    return try {
        val signInOption = GetSignInWithGoogleOption.Builder(webClientId).build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(signInOption)
            .build()
        val response = credentialManager.getCredential(uiContext, request)
        signInWithResponseCredential(response.credential)
    } catch (e: CancellationException) {
        throw e
    } catch (e: GetCredentialCancellationException) {
        val elapsedMs = System.currentTimeMillis() - startTimeMs
        Log.w(AUTH_TAG, "Google Sign-In cancelled or dismissed after ${elapsedMs}ms: ${e.message}", e)
        // If Play Services immediately auto-cancelled before user interaction (< 500ms),
        // retry via GetGoogleIdOption and then OAuthProvider Google account chooser if still unavailable.
        if (elapsedMs < 500L) {
            try {
                return runGoogleIdOptionFallback(filterByAuthorized = false)
            } catch (c: CancellationException) {
                throw c
            } catch (c2: GetCredentialCancellationException) {
                Log.w(AUTH_TAG, "Fallback GoogleIdOption also cancelled: ${c2.message}", c2)
                return GoogleSignInOutcome.Cancelled(
                    com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                        rawMessage = c2.message,
                        context = context,
                        isCancellation = true
                    )
                )
            } catch (f: GetCredentialException) {
                Log.w(AUTH_TAG, "Fallback GoogleIdOption failed (${f.type}): ${f.message}; trying OAuth browser chooser", f)
                return performBrowserGoogleOAuthSignIn(context)
            } catch (f: Exception) {
                Log.e(AUTH_TAG, "Fallback Firebase auth failed", f)
                return GoogleSignInOutcome.Error(
                    com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                        rawMessage = f.localizedMessage,
                        context = context
                    )
                )
            }
        }
        GoogleSignInOutcome.Cancelled(
            com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                rawMessage = e.message,
                context = context,
                isCancellation = true
            )
        )
    } catch (e: NoCredentialException) {
        Log.w(AUTH_TAG, "NoCredential on GetSignInWithGoogleOption; trying GetGoogleIdOption fallback", e)
        try {
            runGoogleIdOptionFallback(filterByAuthorized = false)
        } catch (c: CancellationException) {
            throw c
        } catch (c2: GetCredentialCancellationException) {
            Log.w(AUTH_TAG, "GoogleIdOption cancelled after NoCredential: ${c2.message}", c2)
            GoogleSignInOutcome.Cancelled(
                com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                    rawMessage = c2.message,
                    context = context,
                    isCancellation = true
                )
            )
        } catch (f: GetCredentialException) {
            Log.w(AUTH_TAG, "GoogleIdOption also threw ${f.type}: ${f.message}; launching Google OAuth chooser", f)
            performBrowserGoogleOAuthSignIn(context)
        } catch (f: Exception) {
            Log.e(AUTH_TAG, "Firebase Google auth failure after NoCredential", f)
            GoogleSignInOutcome.Error(
                com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                    rawMessage = f.localizedMessage,
                    context = context
                )
            )
        }
    } catch (e: GetCredentialException) {
        Log.w(AUTH_TAG, "CredentialManager error (${e.type}): ${e.message}", e)
        try {
            runGoogleIdOptionFallback(filterByAuthorized = false)
        } catch (c: CancellationException) {
            throw c
        } catch (c2: GetCredentialCancellationException) {
            Log.w(AUTH_TAG, "Fallback GoogleIdOption cancelled: ${c2.message}", c2)
            GoogleSignInOutcome.Cancelled(
                com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                    rawMessage = c2.message,
                    context = context,
                    isCancellation = true
                )
            )
        } catch (f: GetCredentialException) {
            Log.w(AUTH_TAG, "Fallback GoogleIdOption failed (${f.type}); launching Google OAuth chooser", f)
            performBrowserGoogleOAuthSignIn(context)
        } catch (f: Exception) {
            GoogleSignInOutcome.Error(
                com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                    rawMessage = f.localizedMessage,
                    context = context
                )
            )
        }
    } catch (e: Exception) {
        Log.e(AUTH_TAG, "Firebase Google auth failure", e)
        GoogleSignInOutcome.Error(
            com.example.util.FirebaseDiagnosticsHelper.translateAuthErrorToArabic(
                rawMessage = e.localizedMessage,
                context = context
            )
        )
    }
}

sealed interface GoogleSignInOutcome {
    data object Success : GoogleSignInOutcome
    data class Cancelled(val reason: String? = null) : GoogleSignInOutcome
    data class Error(val message: String) : GoogleSignInOutcome
}

@Composable
fun AuthScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val uiContext = remember(context) { context.findActivity() ?: context }
    val credentialManager = remember(uiContext) { CredentialManager.create(uiContext) }

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Attempt silent authorized-account auto sign-in on mount if user already signed in previously
    LaunchedEffect(Unit) {
        if (Firebase.auth.currentUser == null) {
            attemptSilentGoogleSignIn(uiContext, credentialManager)
        }
    }

    fun launchInteractiveGoogleSignIn(ctx: Context) {
        scope.launch {
            isLoading = true
            errorMessage = null
            when (val outcome = performGoogleSignIn(ctx, credentialManager)) {
                is GoogleSignInOutcome.Success -> Unit
                is GoogleSignInOutcome.Cancelled -> errorMessage = outcome.reason
                is GoogleSignInOutcome.Error -> errorMessage = outcome.message
            }
            isLoading = false
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surface,
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                    )
                )
            )
            .testTag("auth_screen_root"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier.widthIn(max = 460.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    modifier = Modifier
                        .size(104.dp)
                        .shadow(14.dp, CircleShape),
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_inventory_master_1794215182343),
                            contentDescription = "شعار مخزني الذكي",
                            modifier = Modifier
                                .size(90.dp)
                                .clip(CircleShape)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = "مخزني الذكي",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "تسجيل الدخول الآمن لربط القاعدة السحابية الموحدة",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(22.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AuthFeatureRow(
                            icon = Icons.Default.CloudDone,
                            title = "قاعدة بيانات موحدة وفورية",
                            subtitle = "حفظ ومزامنة المخازن والأصناف والوارد والمنصرف لحظياً"
                        )
                        AuthFeatureRow(
                            icon = Icons.Default.Devices,
                            title = "نظام الجهاز الرئيسي والأجهزة الفرعية",
                            subtitle = "ربط الأجهزة بكلمة مرور منفردة لكل جهاز مع تحكم كامل بالصلاحيات والطرد"
                        )
                        AuthFeatureRow(
                            icon = Icons.Default.Restore,
                            title = "استرداد تلقائي بعد إعادة التثبيت",
                            subtitle = "استرجاع كافة بياناتك المحفوظة فور تسجيل الدخول بنفس الحساب"
                        )
                        AuthFeatureRow(
                            icon = Icons.Default.Security,
                            title = "حماية وتشفير عالي الأمان",
                            subtitle = "قواعد وصول محكمة وربط كل كلمة مرور بجهاز واحد فقط"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                if (!errorMessage.isNullOrBlank()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .testTag("auth_error_card"),
                        colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.12f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = errorMessage!!,
                            color = DangerRed,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Button(
                    onClick = { launchInteractiveGoogleSignIn(context) },
                    enabled = !isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("google_signin_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = Color.White,
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("جاري تسجيل الدخول والمزامنة...", fontWeight = FontWeight.Bold)
                    } else {
                        Icon(
                            imageVector = Icons.Default.Login,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "تسجيل الدخول بحساب Google",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "طور بواسطة عيسى عبدربه",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "771438740",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun AuthFeatureRow(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Row(verticalAlignment = Alignment.Top) {
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(34.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
