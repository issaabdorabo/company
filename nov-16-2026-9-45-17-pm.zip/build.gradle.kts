// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
  alias(libs.plugins.android.application) apply false
  alias(libs.plugins.kotlin.compose) apply false
  alias(libs.plugins.google.devtools.ksp) apply false
  alias(libs.plugins.secrets) apply false
  alias(libs.plugins.google.services) apply false
}

// Keep APK signing fingerprint constant across all environments (AI Studio, GitHub Actions, local)
run {
  val debugKeystoreFile = rootProject.file("debug.keystore")
  val debugKeystoreB64File = rootProject.file("debug.keystore.base64")
  if (!debugKeystoreFile.exists() && debugKeystoreB64File.exists()) {
    val cleanB64 = debugKeystoreB64File.readText().replace(Regex("\\s+"), "")
    debugKeystoreFile.writeBytes(java.util.Base64.getDecoder().decode(cleanB64))
  }
}
